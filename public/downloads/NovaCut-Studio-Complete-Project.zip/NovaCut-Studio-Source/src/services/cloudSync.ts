import { ProjectState } from '../types';

const LOCAL_PROJECT_KEY = 'novacut_active_project_v1';
const LOCAL_PROJECTS_LIST_KEY = 'novacut_saved_projects_v1';

export function getInitialProject(): ProjectState {
  try {
    const raw = localStorage.getItem(LOCAL_PROJECT_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    // fallback
  }

  return {
    id: `proj_${Date.now()}`,
    title: 'Viral Reel Edit #1',
    aspectRatio: '9:16', // Default to 9:16 (Facebook Reels / Instagram Reels / TikTok)
    fitMode: 'blur_fill', // Default to viral blurred background mirror!
    clips: [],
    textOverlays: [
      {
        id: 'txt_hook',
        text: '🔥 UNBEATABLE QUALITY',
        startTime: 0.0,
        endTime: 3.5,
        color: '#facc15',
        fontSize: 26,
        position: 'top',
        fontFamily: 'Plus Jakarta Sans',
        animation: 'pop',
      },
      {
        id: 'txt_quote',
        text: '"Your only limit is your mind."',
        startTime: 3.5,
        endTime: 9.5,
        color: '#ffffff',
        fontSize: 24,
        position: 'center',
        fontFamily: 'Plus Jakarta Sans',
        animation: 'fade',
      },
    ],
    filters: {
      brightness: 104,
      contrast: 108,
      saturation: 115,
      sepia: 0,
      blur: 0,
      hueRotate: 0,
      preset: 'crisp_hdr',
    },
    antiCopyright: {
      enabled: true, // Default ON for protection!
      tempoShift: 1.02, // 1.02x micro tempo
      microPitchVariance: true,
      microZoom: 1.03, // 3% zoom
      horizontalFlip: false,
      filmGrain: true,
      colorShiftLut: true,
      subtleAudioDither: true,
    },
    superResolution: {
      autoEnhanceLowRes: true,
      sharpness: 35,
      denoise: 20,
      edgeClarity: 40,
      upscaleTarget: '1080p',
    },
    bulkCreate: {
      enabled: false,
      columns: [
        { id: 'col_1', name: 'Hook (0-3s)', key: 'hook', mappedOverlayId: 'txt_hook' },
        { id: 'col_2', name: 'Main Content', key: 'content', mappedOverlayId: 'txt_quote' },
      ],
      rows: [
        {
          id: 'row_1',
          data: {
            hook: 'DO THIS EVERY MORNING ⚡',
            content: 'Discipline will take you places where motivation cannot.',
          },
          backgroundMediaId: 'sample_1',
        },
        {
          id: 'row_2',
          data: {
            hook: 'PSYCHOLOGY SECRET 🧠',
            content: 'The brain remembers unfinished tasks more than finished ones.',
          },
          backgroundMediaId: 'sample_2',
        },
        {
          id: 'row_3',
          data: {
            hook: 'DON’T IGNORE THIS 🛑',
            content: 'Consistency beats talent when talent fails to show up.',
          },
          backgroundMediaId: 'sample_3',
        },
        {
          id: 'row_4',
          data: {
            hook: 'RULE NUMBER ONE 🎯',
            content: 'Master your morning, master your life.',
          },
          backgroundMediaId: 'sample_4',
        },
      ],
      bgRotationMode: 'cycle', // Auto change background for each video!
      selectedMediaPoolIds: ['sample_1', 'sample_2', 'sample_3', 'sample_4'],
      activePreviewIndex: 0,
    },
    transition: {
      type: 'crossfade',
      duration: 0.8,
      triggerTime: 3.5, // split cue point matching the scene shift
      direction: 'left',
    },
    currentTime: 0,
    duration: 10,
    isCloudSynced: false,
    lastSavedAt: new Date().toISOString(),
  };
}

export function saveProjectLocally(project: ProjectState): void {
  try {
    localStorage.setItem(LOCAL_PROJECT_KEY, JSON.stringify(project));
    
    // Also save into multi-project list
    const listRaw = localStorage.getItem(LOCAL_PROJECTS_LIST_KEY);
    const list: ProjectState[] = listRaw ? JSON.parse(listRaw) : [];
    const filtered = list.filter((p) => p.id !== project.id);
    localStorage.setItem(LOCAL_PROJECTS_LIST_KEY, JSON.stringify([project, ...filtered].slice(0, 20)));
  } catch (e) {
    console.error('Failed to save project locally', e);
  }
}

export async function syncProjectToCloud(project: ProjectState, userEmail: string): Promise<boolean> {
  saveProjectLocally(project);

  if (!navigator.onLine) {
    return false; // Stays saved offline
  }

  try {
    const res = await fetch('/api/sync/save-project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ project, email: userEmail }),
    });
    if (res.ok) {
      return true;
    }
  } catch (e) {
    console.warn('Cloud sync error, saved offline.', e);
  }
  return false;
}

export function exportProjectFile(project: ProjectState): void {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `${project.title.replace(/\s+/g, '_')}.novaproject`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function importProjectFromFile(file: File): Promise<ProjectState> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        if (json && json.id && json.aspectRatio) {
          resolve(json);
        } else {
          reject(new Error('Invalid project file format'));
        }
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
