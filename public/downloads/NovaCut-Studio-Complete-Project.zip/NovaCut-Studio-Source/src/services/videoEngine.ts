import {
  AspectRatioType,
  FitMode,
  VideoClip,
  TextOverlay,
  VideoFilters,
  AntiCopyrightConfig,
  SuperResolutionConfig,
  TransitionConfig,
} from '../types';

export interface CanvasDimensions {
  width: number;
  height: number;
  aspectRatio: AspectRatioType;
}

export function getResolutionDimensions(
  ratio: AspectRatioType,
  targetTier: '720p' | '1080p' | '2k' | '4k' = '1080p'
): { width: number; height: number } {
  const base1080: Record<AspectRatioType, { width: number; height: number }> = {
    '9:16': { width: 1080, height: 1920 },
    '1:1': { width: 1080, height: 1080 },
    '4:5': { width: 1080, height: 1350 },
    '16:9': { width: 1920, height: 1080 },
    '4:3': { width: 1440, height: 1080 },
  };

  const scaleMultiplier = {
    '720p': 0.667,
    '1080p': 1.0,
    '2k': 1.333,
    '4k': 2.0,
  }[targetTier];

  const base = base1080[ratio] || base1080['9:16'];
  return {
    width: Math.round(base.width * scaleMultiplier),
    height: Math.round(base.height * scaleMultiplier),
  };
}

// Generate CSS filter string from filter settings + Anti-Copyright tweaks
export function buildFilterString(
  filters: VideoFilters,
  antiCopyright: AntiCopyrightConfig,
  superRes: SuperResolutionConfig,
  isLowRes: boolean
): string {
  let brightness = filters.brightness;
  let contrast = filters.contrast;
  let saturation = filters.saturation;
  let hue = filters.hueRotate;

  // Apply Anti-Copyright micro-color shift to fool perceptual hashing
  if (antiCopyright.enabled && antiCopyright.colorShiftLut) {
    contrast += 2;
    saturation += 3;
    hue = (hue + 1) % 360;
  }

  // Apply Super-Resolution & Clarity boost if source is low-res (< 780p)
  if (isLowRes && superRes.autoEnhanceLowRes) {
    contrast += Math.round(superRes.edgeClarity * 0.2); // edge micro-contrast boost
    brightness += 2;
    saturation += 4;
  }

  let filterStr = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) hue-rotate(${hue}deg)`;

  if (filters.sepia > 0) {
    filterStr += ` sepia(${filters.sepia}%)`;
  }
  if (filters.blur > 0) {
    filterStr += ` blur(${filters.blur}px)`;
  }

  return filterStr;
}

// Draw a single frame to the canvas with Smart Fitting, Filters, Anti-Copyright Grain, and Text Overlays
export function renderCompositeFrame({
  ctx,
  canvasWidth,
  canvasHeight,
  sourceElement,
  fitMode,
  filters,
  antiCopyright,
  superRes,
  isLowRes,
  currentTime,
  textOverlays,
  transition,
}: {
  ctx: CanvasRenderingContext2D;
  canvasWidth: number;
  canvasHeight: number;
  sourceElement: HTMLVideoElement | HTMLImageElement | null;
  fitMode: FitMode;
  filters: VideoFilters;
  antiCopyright: AntiCopyrightConfig;
  superRes: SuperResolutionConfig;
  isLowRes: boolean;
  currentTime: number;
  textOverlays: TextOverlay[];
  transition?: TransitionConfig;
}): void {
  // Clear canvas
  ctx.fillStyle = '#090d16'; // Deep studio black
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);

  if (!sourceElement) {
    // Draw placeholder grid pattern
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvasWidth; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvasHeight);
      ctx.stroke();
    }
    for (let y = 0; y < canvasHeight; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvasWidth, y);
      ctx.stroke();
    }
    return;
  }

  const srcWidth =
    sourceElement instanceof HTMLVideoElement ? sourceElement.videoWidth : sourceElement.naturalWidth;
  const srcHeight =
    sourceElement instanceof HTMLVideoElement ? sourceElement.videoHeight : sourceElement.naturalHeight;

  if (!srcWidth || !srcHeight) return;

  ctx.save();
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Build filter
  const filterStr = buildFilterString(filters, antiCopyright, superRes, isLowRes);

  // 1. SMART BACKGROUND RENDERING (Gaussian Blur Mirror Fill)
  if (fitMode === 'blur_fill') {
    ctx.save();
    // Heavy blur on background mirror
    ctx.filter = `${filterStr} blur(24px) brightness(60%)`;
    const bgScale = Math.max(canvasWidth / srcWidth, canvasHeight / srcHeight) * 1.25;
    const bgW = srcWidth * bgScale;
    const bgH = srcHeight * bgScale;
    const bgX = (canvasWidth - bgW) / 2;
    const bgY = (canvasHeight - bgH) / 2;
    ctx.drawImage(sourceElement, bgX, bgY, bgW, bgH);
    ctx.restore();

    // Dark overlay scrim to make the centered video pop
    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  }

  // --- TRANSITION STATE CALCULATION ---
  let isTransitionActive = false;
  let transitionProgress = 0; // 0 to 1
  if (transition && transition.type && transition.type !== 'none') {
    const half = (transition.duration || 0.8) / 2;
    const trig = transition.triggerTime || 3.5;
    if (currentTime >= trig - half && currentTime <= trig + half) {
      isTransitionActive = true;
      transitionProgress = Math.max(0, Math.min(1, (currentTime - (trig - half)) / (transition.duration || 0.8)));
    }
  }

  // 2. MAIN FOREGROUND VIDEO RENDERING
  ctx.save();

  // If transition has dynamic blur or scale
  let activeFilter = filterStr;
  if (isTransitionActive) {
    if (transition?.type === 'zoom_blur') {
      const blurAmount = Math.sin(transitionProgress * Math.PI) * 16;
      activeFilter += ` blur(${blurAmount}px)`;
    } else if (transition?.type === 'whip_pan') {
      const blurAmount = Math.sin(transitionProgress * Math.PI) * 20;
      activeFilter += ` blur(${blurAmount}px)`;
    }
  }

  ctx.filter = activeFilter;

  // Calculate target framing
  let targetW = canvasWidth;
  let targetH = canvasHeight;
  let targetX = 0;
  let targetY = 0;

  if (fitMode === 'fill') {
    // Zoom/crop to fill
    const scale = Math.max(canvasWidth / srcWidth, canvasHeight / srcHeight);
    targetW = srcWidth * scale;
    targetH = srcHeight * scale;
    targetX = (canvasWidth - targetW) / 2;
    targetY = (canvasHeight - targetH) / 2;
  } else {
    // 'fit' or 'blur_fill' or 'color' -> keep exact aspect ratio inside container
    const scale = Math.min(canvasWidth / srcWidth, canvasHeight / srcHeight);
    targetW = srcWidth * scale;
    targetH = srcHeight * scale;
    targetX = (canvasWidth - targetW) / 2;
    targetY = (canvasHeight - targetH) / 2;
  }

  // Apply transition motion effects to target position
  if (isTransitionActive && transition) {
    if (transition.type === 'slide_left') {
      const slideOffset = (transitionProgress - 0.5) * canvasWidth * 0.85;
      targetX -= slideOffset;
    } else if (transition.type === 'slide_right') {
      const slideOffset = (transitionProgress - 0.5) * canvasWidth * 0.85;
      targetX += slideOffset;
    } else if (transition.type === 'zoom_blur') {
      const zoomFactor = 1.0 + Math.sin(transitionProgress * Math.PI) * 0.35;
      const prevW = targetW;
      const prevH = targetH;
      targetW *= zoomFactor;
      targetH *= zoomFactor;
      targetX -= (targetW - prevW) / 2;
      targetY -= (targetH - prevH) / 2;
    } else if (transition.type === 'whip_pan') {
      const whip = Math.sin((transitionProgress - 0.5) * Math.PI) * canvasWidth * 0.75;
      targetX -= whip;
    }
  }

  // Anti-Copyright Micro-Zoom (e.g. 1.03x to alter Content-ID spatial bounding box)
  if (antiCopyright.enabled && antiCopyright.microZoom > 1.0) {
    const zoomFactor = antiCopyright.microZoom;
    const zoomedW = targetW * zoomFactor;
    const zoomedH = targetH * zoomFactor;
    targetX -= (zoomedW - targetW) / 2;
    targetY -= (zoomedH - targetH) / 2;
    targetW = zoomedW;
    targetH = zoomedH;
  }

  // Anti-Copyright Horizontal Flip
  if (antiCopyright.enabled && antiCopyright.horizontalFlip) {
    ctx.translate(canvasWidth, 0);
    ctx.scale(-1, 1);
    targetX = canvasWidth - (targetX + targetW);
  }

  // Subtle drop shadow behind fitted video in blur_fill mode
  if (fitMode === 'blur_fill') {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 4;
  }

  ctx.drawImage(sourceElement, targetX, targetY, targetW, targetH);
  ctx.restore();

  // 2.5 POST-DRAW TRANSITION OVERLAYS (Crossfade, Flash White, Glitch, Iris)
  if (isTransitionActive && transition) {
    if (transition.type === 'crossfade') {
      const fadeAlpha = Math.sin(transitionProgress * Math.PI) * 0.85;
      ctx.fillStyle = `rgba(9, 13, 22, ${fadeAlpha})`;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    } else if (transition.type === 'flash_white') {
      const flashAlpha = Math.pow(Math.sin(transitionProgress * Math.PI), 1.5) * 0.95;
      ctx.fillStyle = `rgba(255, 255, 255, ${flashAlpha})`;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    } else if (transition.type === 'glitch') {
      if (transitionProgress > 0.15 && transitionProgress < 0.85) {
        ctx.save();
        for (let g = 0; g < 5; g++) {
          const gy = Math.random() * canvasHeight;
          const gh = 8 + Math.random() * 28;
          ctx.fillStyle = g % 2 === 0 ? 'rgba(6, 182, 212, 0.45)' : 'rgba(244, 63, 94, 0.45)';
          ctx.fillRect(0, gy, canvasWidth, gh);
        }
        ctx.restore();
      }
    } else if (transition.type === 'circle_crop') {
      const maxRadius = Math.hypot(canvasWidth, canvasHeight) / 2;
      const currentR = (1 - Math.sin(transitionProgress * Math.PI) * 0.8) * maxRadius;
      ctx.save();
      ctx.strokeStyle = '#090d16';
      ctx.lineWidth = Math.max(1, maxRadius - currentR);
      ctx.beginPath();
      ctx.arc(canvasWidth / 2, canvasHeight / 2, maxRadius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  // 3. ANTI-COPYRIGHT FILM GRAIN LAYER (Breaks exact cryptographic pixel hash)
  if (antiCopyright.enabled && antiCopyright.filmGrain) {
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
    const grainStep = 8;
    for (let i = 0; i < 400; i++) {
      const rx = Math.random() * canvasWidth;
      const ry = Math.random() * canvasHeight;
      ctx.fillRect(rx, ry, 1.5, 1.5);
    }
    ctx.restore();
  }

  // 4. TEXT OVERLAYS & AUTO-CAPTIONS
  const activeTexts = textOverlays.filter(
    (t) => currentTime >= t.startTime && currentTime <= t.endTime
  );

  activeTexts.forEach((t) => {
    ctx.save();
    const fontSize = Math.max(16, Math.round(t.fontSize * (canvasWidth / 480)));
    ctx.font = `800 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    let posX = canvasWidth / 2;
    let posY = canvasHeight * 0.82; // default bottom position for reels/subtitles

    if (t.position === 'top') {
      posY = canvasHeight * 0.16;
    } else if (t.position === 'center') {
      posY = canvasHeight * 0.5;
    } else if (t.position === 'custom' && t.x !== undefined && t.y !== undefined) {
      posX = (canvasWidth * t.x) / 100;
      posY = (canvasHeight * t.y) / 100;
    }

    // Measure text
    const metrics = ctx.measureText(t.text);
    const textWidth = metrics.width;
    const paddingX = fontSize * 0.6;
    const paddingY = fontSize * 0.35;

    // Background pill / box for maximum legibility
    ctx.fillStyle = t.backgroundColor || 'rgba(0, 0, 0, 0.75)';
    ctx.beginPath();
    const radius = 8;
    const boxX = posX - textWidth / 2 - paddingX;
    const boxY = posY - fontSize / 2 - paddingY;
    const boxW = textWidth + paddingX * 2;
    const boxH = fontSize + paddingY * 2;

    ctx.roundRect
      ? ctx.roundRect(boxX, boxY, boxW, boxH, radius)
      : ctx.rect(boxX, boxY, boxW, boxH);
    ctx.fill();

    // Text stroke / outline
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = Math.max(2, Math.round(fontSize * 0.08));
    ctx.strokeText(t.text, posX, posY);

    // Text fill
    ctx.fillStyle = t.color || '#ffffff';
    ctx.fillText(t.text, posX, posY);

    ctx.restore();
  });

  ctx.restore();
}

// Full Render & Export Engine: Records canvas in real time to create downloadable WebM/MP4
export async function exportVideoFile({
  sourceElement,
  clip,
  aspectRatio,
  fitMode,
  filters,
  antiCopyright,
  superRes,
  textOverlays,
  transition,
  resolutionTier = '1080p',
  onProgress,
}: {
  sourceElement: HTMLVideoElement | HTMLImageElement;
  clip: VideoClip;
  aspectRatio: AspectRatioType;
  fitMode: FitMode;
  filters: VideoFilters;
  antiCopyright: AntiCopyrightConfig;
  superRes: SuperResolutionConfig;
  textOverlays: TextOverlay[];
  transition?: TransitionConfig;
  resolutionTier: '720p' | '1080p' | '2k' | '4k';
  onProgress?: (percent: number) => void;
}): Promise<Blob> {
  const { width: exportWidth, height: exportHeight } = getResolutionDimensions(
    aspectRatio,
    resolutionTier
  );

  const offscreenCanvas = document.createElement('canvas');
  offscreenCanvas.width = exportWidth;
  offscreenCanvas.height = exportHeight;
  const ctx = offscreenCanvas.getContext('2d', { alpha: false });

  if (!ctx) throw new Error('Could not initialize export canvas');

  // Set up audio context to export audio with Anti-Copyright tempo/pitch
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  const audioCtx = new AudioContextClass();
  const destNode = audioCtx.createMediaStreamDestination();

  // If source is a video element with audio
  if (sourceElement instanceof HTMLVideoElement) {
    try {
      const sourceNode = audioCtx.createMediaElementSource(sourceElement);
      // Tempo/playback speed adjusted for Content-ID evasion
      const playbackRate = antiCopyright.enabled ? antiCopyright.tempoShift : 1.0;
      sourceElement.playbackRate = playbackRate;
      sourceNode.connect(destNode);
      sourceNode.connect(audioCtx.destination);
    } catch (e) {
      // already connected or no audio
    }
  }

  // Combined stream (Canvas Video + Web Audio)
  const canvasStream = offscreenCanvas.captureStream(30);
  if (destNode.stream.getAudioTracks().length > 0) {
    destNode.stream.getAudioTracks().forEach((track) => canvasStream.addTrack(track));
  }

  // Select optimal supported mimeType
  const supportedMime = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
    'video/mp4',
  ].find((mime) => MediaRecorder.isTypeSupported(mime)) || 'video/webm';

  const recorder = new MediaRecorder(canvasStream, {
    mimeType: supportedMime,
    videoBitsPerSecond: resolutionTier === '4k' ? 12000000 : 5000000,
  });

  const chunks: Blob[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      chunks.push(e.data);
    }
  };

  return new Promise((resolve, reject) => {
    recorder.onstop = () => {
      const outputBlob = new Blob(chunks, { type: supportedMime });
      resolve(outputBlob);
    };

    recorder.onerror = (err) => reject(err);

    recorder.start(100);

    const totalDuration = clip.duration || 10;
    const fps = 30;
    const totalFrames = Math.round(totalDuration * fps);
    let currentFrame = 0;

    const renderInterval = setInterval(() => {
      const currentTime = (currentFrame / totalFrames) * totalDuration;

      renderCompositeFrame({
        ctx,
        canvasWidth: exportWidth,
        canvasHeight: exportHeight,
        sourceElement,
        fitMode,
        filters,
        antiCopyright,
        superRes,
        isLowRes: clip.isLowRes,
        currentTime,
        textOverlays,
        transition,
      });

      currentFrame++;
      const progress = Math.min(100, Math.round((currentFrame / totalFrames) * 100));
      if (onProgress) onProgress(progress);

      if (currentFrame >= totalFrames) {
        clearInterval(renderInterval);
        setTimeout(() => {
          recorder.stop();
        }, 300);
      }
    }, 1000 / fps);
  });
}
