import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  FolderArchive,
  FileCode,
  HardDrive,
  CheckCircle2,
  ExternalLink,
  Laptop,
  Terminal,
  ShieldCheck,
  Sparkles,
  Info,
} from 'lucide-react';

interface DownloadPackageModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface PackageFileInfo {
  id: string;
  name: string;
  type: string;
  description: string;
  sizeBytes: number;
  sizeFormatted: string;
  downloadUrl: string;
}

export const DownloadPackageModal: React.FC<DownloadPackageModalProps> = ({ isOpen, onClose }) => {
  const [fileList, setFileList] = useState<PackageFileInfo[]>([
    {
      id: 'exe',
      name: 'NovaCut-Studio-Installer.exe',
      type: 'Windows Executable Installer',
      description: 'Native Windows PE32 installer with Desktop shortcut creation & automated offline engine',
      sizeBytes: 2560,
      sizeFormatted: '2.5 KB',
      downloadUrl: '/api/download/exe',
    },
    {
      id: 'windows-zip',
      name: 'NovaCut-Studio-Windows-Desktop-Setup.zip',
      type: 'Windows Desktop Distribution (ZIP)',
      description: 'Complete Windows Desktop package with EXE, Batch installer, Silent VBS launcher, and Urdu guide',
      sizeBytes: 3886644,
      sizeFormatted: '3.7 MB',
      downloadUrl: '/api/download/windows-zip',
    },
    {
      id: 'project-zip',
      name: 'NovaCut-Studio-Complete-Project.zip',
      type: 'Full Source Code & Production Build (ZIP)',
      description: 'Complete project source code, UI components, Gemini AI server, licensing engine, and tests',
      sizeBytes: 3934239,
      sizeFormatted: '3.8 MB',
      downloadUrl: '/api/download/project-zip',
    },
  ]);

  const [activeTab, setActiveTab] = useState<'downloads' | 'guide'>('downloads');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/download/info')
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.files) && data.files.length > 0) {
            setFileList(data.files);
          }
        })
        .catch(() => {
          // fallback to defaults already in state
        });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDownload = (file: PackageFileInfo) => {
    setDownloadingId(file.id);
    const a = document.createElement('a');
    a.href = file.downloadUrl;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => setDownloadingId(null), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Download className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  NovaCut Studio — Downloads & Windows Desktop Package
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Ready
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Windows EXE Installer اور پروجیکٹ کی مکمل ZIP فائلز یہاں سے براہ راست ڈاؤن لوڈ کریں
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-6">
          <button
            onClick={() => setActiveTab('downloads')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'downloads'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            <span>Download Files (ZIP & EXE)</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'guide'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Laptop className="w-4 h-4" />
            <span>انسٹالیشن طریقہ کار (Urdu / English Guide)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-200 text-sm">
          {activeTab === 'downloads' ? (
            <div className="space-y-4">
              <div className="bg-cyan-950/30 border border-cyan-800/40 rounded-xl p-4 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-1">
                  <p className="font-semibold text-cyan-300">
                    ونڈوز ڈیسک ٹاپ سافٹ ویئر اور مکمل سورس کوڈ تیار ہے!
                  </p>
                  <p className="text-slate-400">
                    آپ نیچے دی گئی کسی بھی فائل پر کلک کر کے فوراً اپنے کمپیوٹر میں ڈاؤن لوڈ کر سکتے ہیں۔
                    ڈیسک ٹاپ انسٹالر میں آف لائن لائسنسنگ، کیپ کٹ ٹائم لائن اور کینوا بلک جنریٹر شامل ہے۔
                  </p>
                </div>
              </div>

              {/* Download Cards */}
              <div className="grid gap-3.5">
                {fileList.map((file) => {
                  const isExe = file.name.endsWith('.exe');
                  const isWinZip = file.id === 'windows-zip';

                  return (
                    <div
                      key={file.id}
                      className="group bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all hover:shadow-lg hover:shadow-cyan-950/20"
                    >
                      <div className="flex items-start gap-3.5 min-w-0">
                        <div
                          className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-md ${
                            isExe
                              ? 'bg-gradient-to-tr from-amber-500 to-orange-600 shadow-orange-500/20 text-white'
                              : isWinZip
                              ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-cyan-500/20 text-white'
                              : 'bg-gradient-to-tr from-purple-500 to-indigo-600 shadow-purple-500/20 text-white'
                          }`}
                        >
                          {isExe ? (
                            <HardDrive className="w-5 h-5" />
                          ) : isWinZip ? (
                            <FolderArchive className="w-5 h-5" />
                          ) : (
                            <FileCode className="w-5 h-5" />
                          )}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold text-white text-sm font-mono truncate">
                              {file.name}
                            </span>
                            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                              {file.sizeFormatted}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                            {file.description}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleDownload(file)}
                        className={`w-full sm:w-auto shrink-0 flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs tracking-wide transition-all shadow-md active:scale-95 ${
                          isExe
                            ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 shadow-orange-500/20'
                            : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-cyan-500/20'
                        }`}
                      >
                        <Download className="w-4 h-4 stroke-[2.5]" />
                        <span>
                          {downloadingId === file.id ? 'Downloading...' : 'Download File'}
                        </span>
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Master Owner Notice */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 space-y-1.5">
                <div className="flex items-center gap-2 text-amber-400 font-semibold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>مستقل ماسٹر اونر رسائی (Master Owner Pre-Configured)</span>
                </div>
                <p>
                  اس پیکیج میں آپ کے ای میل ایڈریسز (
                  <span className="text-slate-200 font-mono">josnking01@gmail.com</span> اور{' '}
                  <span className="text-slate-200 font-mono">mayorajput00786@gmail.com</span>) مستقل ماسٹر اونر کے
                  طور پر سیٹ ہیں۔ ونڈوز پر سافٹ ویئر چلاتے ہی یہ خودکار لاگ ان ہو جائے گا۔
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-5 text-xs text-slate-300 leading-relaxed">
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-cyan-400" />
                  <span>ونڈوز پی سی پر انسٹال کرنے کا انتہائی آسان طریقہ (Urdu Steps):</span>
                </h3>
                <ol className="list-decimal list-inside space-y-2 text-slate-300">
                  <li>
                    اوپر <strong className="text-cyan-300">NovaCut-Studio-Windows-Desktop-Setup.zip</strong> ڈاؤن لوڈ
                    کریں اور اسے Right Click کر کے Extract All (Unzip) کریں۔
                  </li>
                  <li>
                    فولڈر کے اندر موجود{' '}
                    <strong className="text-amber-300 font-mono">NovaCut-Studio-Installer.exe</strong> پر ڈبل کلک کریں۔
                    (یا آپ <strong className="text-amber-300 font-mono">Install-NovaCut-Studio.bat</strong> بھی چلا
                    سکتے ہیں)
                  </li>
                  <li>
                    انسٹالر خودکار طریقے سے تمام فائلز سیٹ کرے گا اور آپ کے Desktop پر{' '}
                    <strong className="text-white">"NovaCut Studio"</strong> کا شارٹ کٹ آئیکون بنا دے گا۔
                  </li>
                  <li>
                    اب آپ روزانہ اپنے ڈیسک ٹاپ آئیکون پر ڈبل کلک کر کے بغیر کسی کونسول یا انٹرنیٹ رکاوٹ کے ویڈیو
                    ایڈیٹر استعمال کر سکتے ہیں۔
                  </li>
                </ol>
              </div>

              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 font-mono text-[11px]">
                <div className="text-cyan-400 font-bold mb-1">Package Contents Checklist:</div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>NovaCut-Studio-Installer.exe (Windows Executable)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Install-NovaCut-Studio.bat (One-Click Setup Script)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Launch-NovaCut.vbs (Silent Windowless Background Launcher)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>URDU-INSTALL-GUIDE.txt (مکمل اردو رہنمائی)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Offline Licensing DB & Cryptographic Key Generator</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-slate-400" />
            <span>Direct HTTP Attachment Stream with SHA-256 integrity</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
