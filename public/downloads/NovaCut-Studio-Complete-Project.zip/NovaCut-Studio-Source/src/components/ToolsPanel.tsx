import React, { useState } from 'react';
import {
  Layers,
  Sparkles,
  Shield,
  Tv,
  Palette,
  Type,
  Music,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Folder,
  Wand2,
  Bot,
  Copy,
  Hash,
  Table,
  MoveHorizontal,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import {
  AspectRatioType,
  FitMode,
  VideoClip,
  TextOverlay,
  VideoFilters,
  AntiCopyrightConfig,
  SuperResolutionConfig,
  TransitionConfig,
  TransitionType,
} from '../types';
import { SAMPLE_CLIPS } from '../data/sampleClips';

interface ToolsPanelProps {
  aspectRatio: AspectRatioType;
  onChangeAspectRatio: (ratio: AspectRatioType) => void;
  fitMode: FitMode;
  onChangeFitMode: (mode: FitMode) => void;
  activeClip: VideoClip | null;
  onSelectClip: (clip: VideoClip) => void;
  onUploadFile: (file: File) => void;
  filters: VideoFilters;
  onChangeFilters: (f: VideoFilters) => void;
  antiCopyright: AntiCopyrightConfig;
  onChangeAntiCopyright: (ac: AntiCopyrightConfig) => void;
  superRes: SuperResolutionConfig;
  onChangeSuperRes: (sr: SuperResolutionConfig) => void;
  textOverlays: TextOverlay[];
  onAddTextOverlay: (text: TextOverlay) => void;
  onOpenBulkCreate: () => void;
  transition: TransitionConfig;
  onChangeTransition: (tr: TransitionConfig) => void;
  onPreviewTransition?: () => void;
  currentTime?: number;
}

export const ToolsPanel: React.FC<ToolsPanelProps> = ({
  aspectRatio,
  onChangeAspectRatio,
  fitMode,
  onChangeFitMode,
  activeClip,
  onSelectClip,
  onUploadFile,
  filters,
  onChangeFilters,
  antiCopyright,
  onChangeAntiCopyright,
  superRes,
  onChangeSuperRes,
  textOverlays,
  onAddTextOverlay,
  onOpenBulkCreate,
  transition,
  onChangeTransition,
  onPreviewTransition,
  currentTime = 0,
}) => {
  const [activeTab, setActiveTab] = useState<
    'format' | 'upscale' | 'shield' | 'transitions' | 'ai' | 'filters' | 'text' | 'media' | 'bulk'
  >('format');

  // AI Generation States
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);
  const [copyrightAudit, setCopyrightAudit] = useState<any>(null);
  const [newTextVal, setNewTextVal] = useState('');
  const [textColor, setTextColor] = useState('#facc15');

  // Call Gemini for AI Viral Hooks & Caption Enhancer
  const handleGenerateAiEnhancements = async () => {
    setIsAiLoading(true);
    try {
      const res = await fetch('/api/gemini/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoTitle: activeClip?.name || 'Reels Project',
          topic: 'High Engagement Viral Reels',
          targetPlatform: aspectRatio === '9:16' ? 'Reels / TikTok' : 'Post / Feed',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAiResult(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Call Gemini for AI Copyright Safety Audit
  const handleCheckCopyrightSafety = async () => {
    setIsAiLoading(true);
    try {
      const res = await fetch('/api/gemini/copyright-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoTitle: activeClip?.name || 'Reels Project',
          audioTempo: `${antiCopyright.tempoShift}x`,
          appliedFilters: filters,
        }),
      });
      const data = await res.json();
      if (data.success && data.audit) {
        setCopyrightAudit(data.audit);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Call Gemini for Auto Subtitles / Captions
  const handleGenerateCaptions = async () => {
    setIsAiLoading(true);
    try {
      const res = await fetch('/api/gemini/captions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoDuration: activeClip?.duration || 10,
          theme: 'CapCut Viral Dynamic',
        }),
      });
      const data = await res.json();
      if (data.success && data.captions && Array.isArray(data.captions)) {
        data.captions.forEach((c: any) => {
          onAddTextOverlay({
            id: `caption_${Date.now()}_${Math.random()}`,
            text: c.text,
            startTime: c.start || 0,
            endTime: c.end || 3,
            color: c.color || '#facc15',
            fontSize: c.fontSize || 26,
            position: c.position || 'center',
            fontFamily: 'Plus Jakarta Sans',
            animation: 'pop',
          });
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <aside className="w-80 md:w-96 border-r border-slate-800 bg-slate-900/90 flex flex-col shrink-0 select-none overflow-hidden z-20">
      {/* Sidebar Tool Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800 px-2 py-2 overflow-x-auto no-scrollbar gap-1 bg-slate-950">
        <button
          onClick={() => setActiveTab('format')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'format'
              ? 'bg-slate-800 text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Format</span>
        </button>

        <button
          onClick={() => setActiveTab('upscale')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'upscale'
              ? 'bg-slate-800 text-amber-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Tv className="w-3.5 h-3.5" />
          <span>Upscale</span>
        </button>

        <button
          onClick={() => setActiveTab('shield')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'shield'
              ? 'bg-slate-800 text-emerald-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Shield className="w-3.5 h-3.5" />
          <span>Shield</span>
        </button>

        <button
          onClick={() => setActiveTab('transitions')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'transitions'
              ? 'bg-slate-800 text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MoveHorizontal className="w-3.5 h-3.5" />
          <span>Transitions</span>
        </button>

        <button
          onClick={() => setActiveTab('ai')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'ai'
              ? 'bg-slate-800 text-purple-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>AI Studio</span>
        </button>

        <button
          onClick={() => setActiveTab('filters')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'filters'
              ? 'bg-slate-800 text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>Filters</span>
        </button>

        <button
          onClick={() => setActiveTab('media')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'media'
              ? 'bg-slate-800 text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Folder className="w-3.5 h-3.5" />
          <span>Media</span>
        </button>

        <button
          onClick={() => setActiveTab('bulk')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
            activeTab === 'bulk'
              ? 'bg-purple-900/60 text-purple-300 font-semibold border border-purple-500/40'
              : 'text-purple-400 hover:text-purple-200'
          }`}
        >
          <Table className="w-3.5 h-3.5" />
          <span>Bulk (Canva)</span>
        </button>
      </div>

      {/* Tab Body Contents */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-slate-200">
        {/* TAB 1: FORMAT & AUTO RESIZE */}
        {activeTab === 'format' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white mb-1">Social Aspect Ratio</h3>
              <p className="text-xs text-slate-400">
                Auto-adapts any video into Facebook, Instagram, TikTok or YouTube formats without distortion.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => onChangeAspectRatio('9:16')}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  aspectRatio === '9:16'
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                }`}
              >
                <span className="font-bold">9:16 Vertical Reel</span>
                <span className="text-[11px] text-slate-400 mt-1">FB Reels, IG Reels, TikTok, Shorts</span>
              </button>

              <button
                onClick={() => onChangeAspectRatio('1:1')}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  aspectRatio === '1:1'
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                }`}
              >
                <span className="font-bold">1:1 Square Post</span>
                <span className="text-[11px] text-slate-400 mt-1">Instagram Feed, Facebook Square</span>
              </button>

              <button
                onClick={() => onChangeAspectRatio('4:5')}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  aspectRatio === '4:5'
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                }`}
              >
                <span className="font-bold">4:5 Vertical Feed</span>
                <span className="text-[11px] text-slate-400 mt-1">Instagram Feed Best Aspect</span>
              </button>

              <button
                onClick={() => onChangeAspectRatio('16:9')}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  aspectRatio === '16:9'
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                }`}
              >
                <span className="font-bold">16:9 Landscape</span>
                <span className="text-[11px] text-slate-400 mt-1">YouTube Main & TV screens</span>
              </button>
            </div>

            {/* Smart Canvas Fitting Modes */}
            <div className="pt-3 border-t border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Smart Background Fill (No Pixel Loss)
              </h4>
              <div className="space-y-2">
                <label
                  onClick={() => onChangeFitMode('blur_fill')}
                  className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                    fitMode === 'blur_fill'
                      ? 'border-cyan-500 bg-cyan-500/10'
                      : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="fit"
                    checked={fitMode === 'blur_fill'}
                    onChange={() => onChangeFitMode('blur_fill')}
                    className="mt-0.5 accent-cyan-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Gaussian Blur Mirror Fill</span>
                      <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.2 rounded font-mono">
                        Viral Standard
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Fills empty borders with an aesthetic blurred mirror of the video so pixels stay 100% sharp.
                    </p>
                  </div>
                </label>

                <label
                  onClick={() => onChangeFitMode('fill')}
                  className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                    fitMode === 'fill'
                      ? 'border-cyan-500 bg-cyan-500/10'
                      : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="fit"
                    checked={fitMode === 'fill'}
                    onChange={() => onChangeFitMode('fill')}
                    className="mt-0.5 accent-cyan-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">Smart Center Zoom & Crop</div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Zooms to fill the exact full screen canvas without any black bars.
                    </p>
                  </div>
                </label>

                <label
                  onClick={() => onChangeFitMode('fit')}
                  className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                    fitMode === 'fit'
                      ? 'border-cyan-500 bg-cyan-500/10'
                      : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="fit"
                    checked={fitMode === 'fit'}
                    onChange={() => onChangeFitMode('fit')}
                    className="mt-0.5 accent-cyan-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">Letterbox Frame (Fit to Screen)</div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Maintains original video aspect ratio with clean matte letterboxing.
                    </p>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LOW-RESOLUTION AUTO-UPSCALER (<780p Auto Enhancer) */}
        {activeTab === 'upscale' && (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
              <div className="flex items-center gap-2 text-amber-300 font-bold mb-1">
                <Tv className="w-4 h-4" />
                <span>Auto &lt;780p Clarity Enhancer</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Jab bhi koi video 780p se kam resolution ki ho (jaise 480p, 640p, 720p), yeh engine automatically
                sharpening, contrast edge curves, aur bicubic neural restoration apply karke crisp 1080p/2K/4K me
                convert karta hai.
              </p>
            </div>

            {/* Current Source Detection */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1.5 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Source Resolution:</span>
                <span className="text-white font-semibold">
                  {activeClip ? `${activeClip.width}x${activeClip.height}` : '1080x1920'}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Under 780p Detected:</span>
                <span className={activeClip?.isLowRes ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                  {activeClip?.isLowRes ? 'YES (<780p Low-Res)' : 'NO (High Definition)'}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Clarity Enhancement:</span>
                <span className="text-cyan-400 font-bold">
                  {superRes.autoEnhanceLowRes ? 'ACTIVE (Sharpen & Denoise)' : 'DISABLED'}
                </span>
              </div>
            </div>

            {/* Target Upscale Selector */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2">Target Upscale Output</label>
              <div className="grid grid-cols-3 gap-2">
                {(['1080p', '2k', '4k'] as const).map((tier) => (
                  <button
                    key={tier}
                    onClick={() => onChangeSuperRes({ ...superRes, upscaleTarget: tier })}
                    className={`py-2 px-3 rounded-lg border text-xs font-bold uppercase transition-all ${
                      superRes.upscaleTarget === tier
                        ? 'border-amber-400 bg-amber-400/10 text-amber-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tier}
                  </button>
                ))}
              </div>
            </div>

            {/* Fine-Tuning Sliders */}
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Edge Clarity & Sharpness</span>
                  <span className="font-mono text-cyan-400">{superRes.sharpness}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={superRes.sharpness}
                  onChange={(e) =>
                    onChangeSuperRes({ ...superRes, sharpness: Number(e.target.value) })
                  }
                  className="w-full accent-cyan-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Pixel Smoothing & Anti-Aliasing</span>
                  <span className="font-mono text-cyan-400">{superRes.denoise}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={superRes.denoise}
                  onChange={(e) => onChangeSuperRes({ ...superRes, denoise: Number(e.target.value) })}
                  className="w-full accent-cyan-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ANTI-COPYRIGHT AUTO SHIELD */}
        {activeTab === 'shield' && (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                  <Shield className="w-4 h-4" />
                  <span>Auto Anti-Copyright Shield</span>
                </div>
                <button
                  onClick={() => onChangeAntiCopyright({ ...antiCopyright, enabled: !antiCopyright.enabled })}
                  className={`px-2.5 py-0.5 rounded text-xs font-bold uppercase transition-colors ${
                    antiCopyright.enabled
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {antiCopyright.enabled ? 'ON' : 'OFF'}
                </button>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Yeh automated system video ke audio aur video signals me micro-adjustments karta hai taake
                Facebook Reels, TikTok aur YouTube par automatic Content-ID aur Copyright strike na aaye.
              </p>
            </div>

            {/* Shield Parameters */}
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Audio Tempo & Pitch Shift</span>
                  <span className="font-mono text-emerald-400">{antiCopyright.tempoShift}x</span>
                </div>
                <input
                  type="range"
                  min="0.95"
                  max="1.05"
                  step="0.01"
                  value={antiCopyright.tempoShift}
                  onChange={(e) =>
                    onChangeAntiCopyright({ ...antiCopyright, tempoShift: Number(e.target.value) })
                  }
                  className="w-full accent-emerald-500"
                />
                <span className="text-[10px] text-slate-500">
                  Recommended: 1.02x (+2% imperceptible speed shift breaks audio fingerprints)
                </span>
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Micro Spatial Zoom (Visual Hash Evasion)</span>
                  <span className="font-mono text-emerald-400">{antiCopyright.microZoom}x</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="1.08"
                  step="0.01"
                  value={antiCopyright.microZoom}
                  onChange={(e) =>
                    onChangeAntiCopyright({ ...antiCopyright, microZoom: Number(e.target.value) })
                  }
                  className="w-full accent-emerald-500"
                />
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                <label className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <span>Dynamic Micro Film Grain</span>
                  <input
                    type="checkbox"
                    checked={antiCopyright.filmGrain}
                    onChange={(e) =>
                      onChangeAntiCopyright({ ...antiCopyright, filmGrain: e.target.checked })
                    }
                    className="accent-emerald-500"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <span>Anti-Perceptual Color LUT (Gamma Shift)</span>
                  <input
                    type="checkbox"
                    checked={antiCopyright.colorShiftLut}
                    onChange={(e) =>
                      onChangeAntiCopyright({ ...antiCopyright, colorShiftLut: e.target.checked })
                    }
                    className="accent-emerald-500"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <span>Horizontal Flip (Mirror Mode)</span>
                  <input
                    type="checkbox"
                    checked={antiCopyright.horizontalFlip}
                    onChange={(e) =>
                      onChangeAntiCopyright({ ...antiCopyright, horizontalFlip: e.target.checked })
                    }
                    className="accent-emerald-500"
                  />
                </label>
              </div>
            </div>

            {/* AI Copyright Safety Auditor */}
            <div className="pt-2 border-t border-slate-800">
              <button
                onClick={handleCheckCopyrightSafety}
                disabled={isAiLoading}
                className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-emerald-300 flex items-center justify-center gap-2 border border-slate-700 transition-colors"
              >
                <Bot className="w-3.5 h-3.5" />
                <span>{isAiLoading ? 'Analyzing...' : 'Audit Copyright Safety (AI)'}</span>
              </button>

              {copyrightAudit && (
                <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-emerald-500/30 text-xs space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Content-ID Safety Score:</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm">
                      {copyrightAudit.safetyScore}% ({copyrightAudit.riskLevel})
                    </span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-500 text-[10px] block font-semibold uppercase">
                      Protected Vectors:
                    </span>
                    {copyrightAudit.detectionVectors?.map((v: string, i: number) => (
                      <div key={i} className="flex items-center gap-1.5 text-[11px] text-slate-300">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span>{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB: TRANSITIONS PANEL */}
        {activeTab === 'transitions' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <MoveHorizontal className="w-4 h-4 text-indigo-400" />
                <span>Video Transitions Studio</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Add professional cross-fades, slides, zoom blurs, or flash cuts between video segments.
              </p>
            </div>

            {/* Quick Test & Preview Button */}
            <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-white block">
                  Active: {transition.type === 'none' ? 'None (Hard Cut)' : transition.type.replace('_', ' ').toUpperCase()}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  At {transition.triggerTime.toFixed(1)}s (Duration: {transition.duration}s)
                </span>
              </div>

              {onPreviewTransition && (
                <button
                  onClick={onPreviewTransition}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm shadow-indigo-600/20 active:scale-95 transition-all"
                  title="Play video right before the transition point to preview"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview</span>
                </button>
              )}
            </div>

            {/* Transition Cards Grid */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">Select Transition Effect</label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  {
                    id: 'crossfade',
                    name: 'Cross-Fade',
                    desc: 'Smooth cinematic dip & dissolve',
                    badge: 'Universal',
                  },
                  {
                    id: 'zoom_blur',
                    name: 'Zoom Blur',
                    desc: 'CapCut viral radial punch zoom',
                    badge: 'Trending',
                  },
                  {
                    id: 'slide_left',
                    name: 'Slide Left',
                    desc: 'Dynamic horizontal swipe push',
                    badge: 'Clean',
                  },
                  {
                    id: 'slide_right',
                    name: 'Slide Right',
                    desc: 'Reverse horizontal scene push',
                    badge: 'Clean',
                  },
                  {
                    id: 'whip_pan',
                    name: 'Whip Pan',
                    desc: 'High-speed camera motion streak',
                    badge: 'Kinetic',
                  },
                  {
                    id: 'flash_white',
                    name: 'Flash White',
                    desc: 'Impact strobe for beat drops',
                    badge: 'Impact',
                  },
                  {
                    id: 'glitch',
                    name: 'Glitch Artifact',
                    desc: 'Cyberpunk slice distortion',
                    badge: 'Edgy',
                  },
                  {
                    id: 'circle_crop',
                    name: 'Circle Iris',
                    desc: 'Classic spotlight wipe',
                    badge: 'Retro',
                  },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() =>
                      onChangeTransition({
                        ...transition,
                        type: item.id as TransitionType,
                      })
                    }
                    className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                      transition.type === item.id
                        ? 'border-indigo-500 bg-indigo-500/15 text-indigo-200 shadow-sm shadow-indigo-500/10'
                        : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{item.name}</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 font-mono text-slate-400">
                        {item.badge}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 line-clamp-2">
                      {item.desc}
                    </span>
                  </button>
                ))}
              </div>

              {/* None / Clear Transition Option */}
              <button
                onClick={() =>
                  onChangeTransition({
                    ...transition,
                    type: 'none',
                  })
                }
                className={`w-full py-2 px-3 rounded-lg border text-xs font-medium text-center transition-colors ${
                  transition.type === 'none'
                    ? 'border-slate-700 bg-slate-800 text-white'
                    : 'border-slate-800/80 bg-slate-950/40 text-slate-500 hover:text-slate-300'
                }`}
              >
                No Transition (Direct Hard Cut)
              </button>
            </div>

            {/* Fine-Tuning Controls */}
            {transition.type !== 'none' && (
              <div className="space-y-4 pt-3 border-t border-slate-800">
                {/* Transition Duration Slider */}
                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Transition Duration</span>
                    <span className="font-mono text-indigo-400 font-semibold">
                      {transition.duration.toFixed(2)}s
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.3"
                    max="2.0"
                    step="0.05"
                    value={transition.duration}
                    onChange={(e) =>
                      onChangeTransition({
                        ...transition,
                        duration: Number(e.target.value),
                      })
                    }
                    className="w-full accent-indigo-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                    <span>Snappy (0.3s)</span>
                    <span>Smooth (0.8s)</span>
                    <span>Cinematic (2.0s)</span>
                  </div>
                </div>

                {/* Transition Trigger Time Slider */}
                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Trigger Cue Point</span>
                    <span className="font-mono text-indigo-400 font-semibold">
                      {transition.triggerTime.toFixed(1)}s
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max={Math.max(1, (activeClip?.duration || 10) - 0.5)}
                    step="0.1"
                    value={transition.triggerTime}
                    onChange={(e) =>
                      onChangeTransition({
                        ...transition,
                        triggerTime: Number(e.target.value),
                      })
                    }
                    className="w-full accent-indigo-500"
                  />
                </div>

                {/* Quick Align to Current Playhead */}
                <button
                  onClick={() =>
                    onChangeTransition({
                      ...transition,
                      triggerTime: Math.max(0.5, Math.min(currentTime, (activeClip?.duration || 10) - 0.5)),
                    })
                  }
                  className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Align Transition to Current Playhead ({currentTime.toFixed(1)}s)</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: GEMINI AI STUDIO */}
        {activeTab === 'ai' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>AI Creative Studio</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Powered by Gemini 3.8 Flash for viral short-form retention & dynamic subtitles.
              </p>
            </div>

            {/* 1. Auto Subtitles / Captions */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-white">Viral Auto Captions</span>
                <button
                  onClick={handleGenerateCaptions}
                  disabled={isAiLoading}
                  className="px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-md text-xs font-medium transition-colors"
                >
                  {isAiLoading ? 'Generating...' : 'Auto-Generate'}
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                Adds high-retention synchronized caption overlays on the timeline automatically.
              </p>
            </div>

            {/* 2. Viral Hooks & Script Retention */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">Viral Hooks & Script</span>
                <button
                  onClick={handleGenerateAiEnhancements}
                  disabled={isAiLoading}
                  className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-md text-xs font-medium transition-colors"
                >
                  {isAiLoading ? 'Thinking...' : 'Analyze Hooks'}
                </button>
              </div>

              {aiResult && (
                <div className="space-y-3 pt-2 text-xs">
                  <div>
                    <span className="text-slate-400 font-semibold block mb-1">Scroll-Stopping 3s Hooks:</span>
                    <ul className="space-y-1">
                      {aiResult.viralHooks?.map((h: string, i: number) => (
                        <li
                          key={i}
                          onClick={() => {
                            onAddTextOverlay({
                              id: `hook_${Date.now()}_${i}`,
                              text: h,
                              startTime: 0,
                              endTime: 3,
                              color: '#38bdf8',
                              fontSize: 26,
                              position: 'center',
                              fontFamily: 'Plus Jakarta Sans',
                              animation: 'pop',
                            });
                          }}
                          className="p-2 rounded bg-slate-900 border border-slate-800 hover:border-cyan-500 cursor-pointer text-[11px] text-cyan-200"
                          title="Click to add as opening title overlay"
                        >
                          "{h}"
                        </li>
                      ))}
                    </ul>
                  </div>

                  {aiResult.hashtags && (
                    <div>
                      <span className="text-slate-400 font-semibold block mb-1">Recommended Hashtags:</span>
                      <div className="flex flex-wrap gap-1">
                        {aiResult.hashtags.map((tag: string, i: number) => (
                          <span
                            key={i}
                            className="text-[10px] bg-slate-900 px-2 py-0.5 rounded text-purple-300 font-mono"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Quick Text Add */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-semibold text-white block">Custom Text Overlay</span>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter video text..."
                  value={newTextVal}
                  onChange={(e) => setNewTextVal(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
                <button
                  onClick={() => {
                    if (!newTextVal.trim()) return;
                    onAddTextOverlay({
                      id: `txt_${Date.now()}`,
                      text: newTextVal.trim(),
                      startTime: 0,
                      endTime: 5,
                      color: textColor,
                      fontSize: 26,
                      position: 'center',
                      fontFamily: 'Plus Jakarta Sans',
                      animation: 'pop',
                    });
                    setNewTextVal('');
                  }}
                  className="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold rounded"
                >
                  Add
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: FILTERS & COLOR GRADING */}
        {activeTab === 'filters' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white mb-2">Cinematic Color Presets</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: 'crisp_hdr', label: 'Crisp HDR', b: 104, c: 110, s: 120 },
                { id: 'cinematic', label: 'Cinematic Movie', b: 96, c: 125, s: 110 },
                { id: 'cyberpunk', label: 'Cyberpunk Neon', b: 102, c: 120, s: 150 },
                { id: 'clean_studio', label: 'Clean Studio', b: 100, c: 100, s: 100 },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() =>
                    onChangeFilters({
                      ...filters,
                      preset: p.id as any,
                      brightness: p.b,
                      contrast: p.c,
                      saturation: p.s,
                    })
                  }
                  className={`p-2.5 rounded-lg border text-left font-medium transition-colors ${
                    filters.preset === p.id
                      ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                      : 'border-slate-800 bg-slate-950 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Sliders */}
            <div className="space-y-3 pt-3 border-t border-slate-800">
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Brightness</span>
                  <span className="font-mono text-cyan-400">{filters.brightness}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="140"
                  value={filters.brightness}
                  onChange={(e) => onChangeFilters({ ...filters, brightness: Number(e.target.value) })}
                  className="w-full accent-cyan-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Contrast</span>
                  <span className="font-mono text-cyan-400">{filters.contrast}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="160"
                  value={filters.contrast}
                  onChange={(e) => onChangeFilters({ ...filters, contrast: Number(e.target.value) })}
                  className="w-full accent-cyan-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Saturation</span>
                  <span className="font-mono text-cyan-400">{filters.saturation}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={filters.saturation}
                  onChange={(e) => onChangeFilters({ ...filters, saturation: Number(e.target.value) })}
                  className="w-full accent-cyan-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: MEDIA & SAMPLE CLIPS */}
        {activeTab === 'media' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white mb-1">Select or Upload Media</h3>
              <p className="text-xs text-slate-400">
                Choose a built-in HD/4K clip or test the low-res &lt;780p upscaler clip.
              </p>
            </div>

            {/* Sample clips list */}
            <div className="space-y-2">
              {SAMPLE_CLIPS.map((clip) => (
                <div
                  key={clip.id}
                  onClick={() => onSelectClip(clip)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                    activeClip?.id === clip.id
                      ? 'border-cyan-500 bg-cyan-500/10'
                      : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <p className="text-xs font-bold text-white truncate">{clip.name}</p>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1 font-mono">
                      <span>{clip.duration}s</span>
                      <span>·</span>
                      <span>{clip.width}x{clip.height}</span>
                      {clip.isLowRes && (
                        <span className="text-amber-400 font-bold bg-amber-500/20 px-1 rounded">
                          &lt;780p Low-Res
                        </span>
                      )}
                    </div>
                  </div>
                  {activeClip?.id === clip.id && (
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: CANVA BULK CREATE ENGINE */}
        {activeTab === 'bulk' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-gradient-to-tr from-purple-900/30 via-indigo-900/20 to-cyan-900/20 border border-purple-500/30 space-y-3">
              <div className="flex items-center gap-2">
                <Table className="w-5 h-5 text-purple-400" />
                <h3 className="text-sm font-bold text-white">Canva-Style Bulk Video Automation</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Ek template banayein aur usme bulk data daal kar hazaron unique videos generate karein. Har video ka background automatically change ho sakta hai!
              </p>

              <button
                onClick={onOpenBulkCreate}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all active:scale-95"
              >
                <Table className="w-4 h-4" />
                <span>Open Full Bulk Spreadsheet Studio</span>
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-semibold text-white flex items-center gap-2">
                  <span className="text-cyan-400 font-bold">01.</span>
                  <span>Auto Background Rotation</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Har nayi video me background clip automatically cycle ya randomize ho jati hai taake content kabhi repeat na lage.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-semibold text-white flex items-center gap-2">
                  <span className="text-purple-400 font-bold">02.</span>
                  <span>Connect Data to Text Layers</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Canva Bulk Create ki tarah column data (Hook, Quote, Author, CTA) direct timeline ke text layers se bind hota hai.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-semibold text-white flex items-center gap-2">
                  <span className="text-emerald-400 font-bold">03.</span>
                  <span>Batch Rendering & Anti-Copyright</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Tamam videos ek click me sequential render hoti hain aur Content-ID shield aur duplicate protection lag jati hai.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
