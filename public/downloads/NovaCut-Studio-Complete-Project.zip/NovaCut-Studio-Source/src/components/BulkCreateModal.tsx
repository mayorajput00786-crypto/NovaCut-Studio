import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Table,
  Upload,
  Plus,
  Trash2,
  Film,
  RefreshCw,
  Play,
  Download,
  CheckCircle2,
  AlertCircle,
  Link,
  Layers,
  ArrowRight,
  Shuffle,
  FileSpreadsheet,
  Check,
} from 'lucide-react';
import {
  ProjectState,
  BulkCreateConfig,
  BulkDataColumn,
  BulkDataRow,
  TextOverlay,
  VideoClip,
  UserProfile,
} from '../types';
import { SAMPLE_CLIPS } from '../data/sampleClips';
import { exportVideoFile } from '../services/videoEngine';
import { generateVideoFingerprint, recordNewExport } from '../services/duplicateRegistry';

interface BulkCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: ProjectState;
  onUpdateBulkConfig: (config: BulkCreateConfig) => void;
  onSelectPreviewRow: (rowIndex: number) => void;
  activeClip: VideoClip | null;
  currentUser: UserProfile;
}

export const BulkCreateModal: React.FC<BulkCreateModalProps> = ({
  isOpen,
  onClose,
  project,
  onUpdateBulkConfig,
  onSelectPreviewRow,
  activeClip,
  currentUser,
}) => {
  const bulkConfig = project.bulkCreate;
  const [selectedTopic, setSelectedTopic] = useState('Viral Motivational Quotes');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [csvTextModalOpen, setCsvTextModalOpen] = useState(false);
  const [csvRawText, setCsvRawText] = useState('');

  // Batch Exporting State
  const [isBatchExporting, setIsBatchExporting] = useState(false);
  const [currentBatchIndex, setCurrentBatchIndex] = useState(0);
  const [batchProgress, setBatchProgress] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);

  if (!isOpen) return null;

  // Add new row
  const handleAddRow = () => {
    const newRowId = `row_${Date.now()}`;
    const initialData: Record<string, string> = {};
    bulkConfig.columns.forEach((col) => {
      initialData[col.key] = '';
    });

    // Auto-assign next background if cycle mode
    const nextBgIndex = bulkConfig.rows.length % SAMPLE_CLIPS.length;
    const assignedBg = SAMPLE_CLIPS[nextBgIndex].id;

    const newRows = [
      ...bulkConfig.rows,
      {
        id: newRowId,
        data: initialData,
        backgroundMediaId: assignedBg,
      },
    ];

    onUpdateBulkConfig({
      ...bulkConfig,
      enabled: true,
      rows: newRows,
    });
  };

  // Delete row
  const handleDeleteRow = (rowId: string) => {
    const updated = bulkConfig.rows.filter((r) => r.id !== rowId);
    onUpdateBulkConfig({
      ...bulkConfig,
      rows: updated,
      activePreviewIndex: Math.min(bulkConfig.activePreviewIndex, Math.max(0, updated.length - 1)),
    });
  };

  // Update cell text
  const handleCellChange = (rowId: string, colKey: string, value: string) => {
    const updated = bulkConfig.rows.map((row) => {
      if (row.id === rowId) {
        return {
          ...row,
          data: {
            ...row.data,
            [colKey]: value,
          },
        };
      }
      return row;
    });

    onUpdateBulkConfig({
      ...bulkConfig,
      rows: updated,
    });
  };

  // Change background media for a specific row
  const handleRowBgChange = (rowId: string, bgId: string) => {
    const updated = bulkConfig.rows.map((row) => {
      if (row.id === rowId) {
        return {
          ...row,
          backgroundMediaId: bgId,
        };
      }
      return row;
    });

    onUpdateBulkConfig({
      ...bulkConfig,
      rows: updated,
    });
  };

  // Map Column to Text Overlay Layer
  const handleMapColumn = (colId: string, layerId: string) => {
    const updated = bulkConfig.columns.map((col) => {
      if (col.id === colId) {
        return {
          ...col,
          mappedOverlayId: layerId || undefined,
        };
      }
      return col;
    });

    onUpdateBulkConfig({
      ...bulkConfig,
      columns: updated,
    });
  };

  // AI Bulk Generate Data
  const handleAiBulkGenerate = async () => {
    setIsAiGenerating(true);
    try {
      const res = await fetch('/api/gemini/bulk-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: selectedTopic, count: 6 }),
      });
      const data = await res.json();
      if (data.success && data.items && Array.isArray(data.items)) {
        const generatedRows: BulkDataRow[] = data.items.map((item: any, idx: number) => {
          const bgIndex = idx % SAMPLE_CLIPS.length;
          return {
            id: `row_ai_${Date.now()}_${idx}`,
            data: {
              hook: item.hook || 'TOP SECRET ⚡',
              content: item.content || 'Discipline creates real freedom.',
            },
            backgroundMediaId: SAMPLE_CLIPS[bgIndex].id,
          };
        });

        onUpdateBulkConfig({
          ...bulkConfig,
          enabled: true,
          rows: generatedRows,
          activePreviewIndex: 0,
        });
        onSelectPreviewRow(0);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Import CSV text
  const handleParseCsv = () => {
    if (!csvRawText.trim()) return;
    const lines = csvRawText.trim().split('\n');
    if (lines.length < 2) return;

    const headers = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
    const cols: BulkDataColumn[] = headers.map((h, i) => ({
      id: `col_csv_${i}`,
      name: h,
      key: h.toLowerCase().replace(/[^a-z0-9]/g, '_'),
      mappedOverlayId: project.textOverlays[i]?.id,
    }));

    const rows: BulkDataRow[] = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const parts = line.split(',').map((p) => p.trim().replace(/^"|"$/g, ''));
      const rowData: Record<string, string> = {};
      cols.forEach((col, cIdx) => {
        rowData[col.key] = parts[cIdx] || '';
      });
      const bgIdx = (i - 1) % SAMPLE_CLIPS.length;
      rows.push({
        id: `row_csv_${i}`,
        data: rowData,
        backgroundMediaId: SAMPLE_CLIPS[bgIdx].id,
      });
    }

    onUpdateBulkConfig({
      ...bulkConfig,
      enabled: true,
      columns: cols,
      rows,
      activePreviewIndex: 0,
    });
    setCsvTextModalOpen(false);
    setCsvRawText('');
    onSelectPreviewRow(0);
  };

  // Batch Export All Videos
  const handleBatchRenderAll = async () => {
    if (bulkConfig.rows.length === 0) return;
    setIsBatchExporting(true);
    setCurrentBatchIndex(0);
    setCompletedCount(0);

    for (let i = 0; i < bulkConfig.rows.length; i++) {
      setCurrentBatchIndex(i);
      setBatchProgress(5);

      const row = bulkConfig.rows[i];
      // Resolve background clip
      let rowBgClip = activeClip;
      if (bulkConfig.bgRotationMode === 'cycle') {
        const clipIdx = i % SAMPLE_CLIPS.length;
        rowBgClip = SAMPLE_CLIPS[clipIdx];
      } else if (bulkConfig.bgRotationMode === 'random') {
        const randIdx = Math.floor(Math.random() * SAMPLE_CLIPS.length);
        rowBgClip = SAMPLE_CLIPS[randIdx];
      } else if (bulkConfig.bgRotationMode === 'specific' && row.backgroundMediaId) {
        rowBgClip = SAMPLE_CLIPS.find((c) => c.id === row.backgroundMediaId) || activeClip;
      }

      // Substitute dynamic text overlays for this row
      const substitutedOverlays: TextOverlay[] = project.textOverlays.map((layer) => {
        const matchingCol = bulkConfig.columns.find((col) => col.mappedOverlayId === layer.id);
        if (matchingCol && row.data[matchingCol.key]) {
          return {
            ...layer,
            text: row.data[matchingCol.key],
          };
        }
        return layer;
      });

      // Prepare DOM media element
      const clipToRender = rowBgClip || SAMPLE_CLIPS[0];
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = clipToRender.src;
      await new Promise((r) => {
        img.onload = r;
        setTimeout(r, 600);
      });

      // Render video
      try {
        const blob = await exportVideoFile({
          sourceElement: img,
          clip: clipToRender,
          aspectRatio: project.aspectRatio,
          fitMode: project.fitMode,
          filters: project.filters,
          antiCopyright: project.antiCopyright,
          superRes: project.superResolution,
          textOverlays: substitutedOverlays,
          resolutionTier: project.superResolution.upscaleTarget || '1080p',
          onProgress: (p) => setBatchProgress(p),
        });

        // Trigger individual file download
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const cleanName = (row.data.hook || `Bulk_Video_${i + 1}`)
          .slice(0, 20)
          .replace(/[^a-zA-Z0-9]/g, '_');
        a.download = `${cleanName}_${project.aspectRatio.replace(':', 'x')}.webm`;
        document.body.appendChild(a);
        a.click();
        a.remove();

        // Record in duplicate registry
        const fp = generateVideoFingerprint(cleanName, clipToRender.duration, clipToRender.name);
        await recordNewExport(
          fp,
          cleanName,
          clipToRender.duration,
          project.aspectRatio,
          '1080p',
          currentUser.email
        );

        setCompletedCount((prev) => prev + 1);
      } catch (err) {
        console.error(`Failed to export row ${i + 1}`, err);
      }
    }

    setIsBatchExporting(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 md:p-6">
      <div className="w-full max-w-6xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Table className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Canva-Style Bulk Video Automation</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 font-mono">
                  BULK CREATE ENGINE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                1 Template se 10-100 unique videos banayein with auto-changing backgrounds aur dynamic text layers.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar (AI Generator + CSV Upload + Background Mode) */}
        <div className="px-6 py-3 border-b border-slate-800 bg-slate-900/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* AI Bulk Generator Pill */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>AI Data Generator:</span>
            </span>
            <select
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-purple-500"
            >
              <option value="Viral Motivational Quotes">Motivational Quotes & Discipline</option>
              <option value="Psychology Facts for Reels">Dark Psychology Facts</option>
              <option value="Business & Wealth Rules">Business & Money Mindset</option>
              <option value="Did You Know Life Secrets">Crazy Life Facts</option>
              <option value="Fitness & Health Wisdom">Health & Fitness Truths</option>
            </select>
            <button
              onClick={handleAiBulkGenerate}
              disabled={isAiGenerating}
              className="px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold transition-colors flex items-center gap-1.5 shadow-sm shadow-purple-600/20"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isAiGenerating ? 'Generating 6 Videos...' : 'Generate AI Data'}</span>
            </button>
          </div>

          {/* Background Rotation Controller (KEY FEATURE USER REQUESTED) */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Film className="w-3.5 h-3.5 text-cyan-400" />
              <span>Auto-Change Backgrounds:</span>
            </span>
            <select
              value={bulkConfig.bgRotationMode}
              onChange={(e) =>
                onUpdateBulkConfig({
                  ...bulkConfig,
                  bgRotationMode: e.target.value as any,
                })
              }
              className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-cyan-300 font-semibold focus:outline-none focus:border-cyan-500"
              title="Automatically switch backgrounds for every generated video!"
            >
              <option value="cycle">🔄 Auto-Cycle (Clip 1 → Clip 2 → Clip 3...)</option>
              <option value="random">🔀 Random Background per Video</option>
              <option value="specific">🎯 Custom Selected per Row in Table</option>
              <option value="same">🔒 Same Background for All</option>
            </select>
          </div>

          {/* CSV Import */}
          <button
            onClick={() => setCsvTextModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Paste / Upload CSV</span>
          </button>
        </div>

        {/* Content Area: Spreadsheet Table with Column-to-Layer Linkers */}
        <div className="flex-1 overflow-auto p-6 space-y-4">
          {/* Column Layer Linking Header */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold">
                <Link className="w-4 h-4 text-cyan-400" />
                <span>Connect Data Fields to Video Layers (Like Canva Bulk Create)</span>
              </div>
              <span className="text-slate-400 text-[11px]">
                Each column dynamically replaces a video text overlay on your timeline.
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
              {bulkConfig.columns.map((col) => (
                <div
                  key={col.id}
                  className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div>
                    <span className="font-semibold text-slate-200 block">{col.name}</span>
                    <span className="text-[10px] font-mono text-slate-500">Column: {col.key}</span>
                  </div>

                  <select
                    value={col.mappedOverlayId || ''}
                    onChange={(e) => handleMapColumn(col.id, e.target.value)}
                    className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs text-cyan-300 font-medium focus:outline-none focus:border-cyan-500 max-w-[140px] truncate"
                  >
                    <option value="">-- No Binding --</option>
                    {project.textOverlays.map((layer) => (
                      <option key={layer.id} value={layer.id}>
                        {layer.text.slice(0, 16)}...
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Bulk Data Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950 shadow-inner">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 border-b border-slate-800 text-slate-400 select-none">
                <tr>
                  <th className="py-2.5 px-3 w-16 text-center font-mono">#</th>
                  {bulkConfig.columns.map((col) => (
                    <th key={col.id} className="py-2.5 px-4 font-semibold text-slate-300">
                      {col.name}
                    </th>
                  ))}
                  <th className="py-2.5 px-4 font-semibold text-cyan-400">
                    Video Background (Auto-Rotate)
                  </th>
                  <th className="py-2.5 px-4 text-center w-28">Preview</th>
                  <th className="py-2.5 px-3 w-12 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {bulkConfig.rows.map((row, idx) => {
                  const isCurrentPreview = bulkConfig.activePreviewIndex === idx;

                  // Resolve display background for this row
                  const effectiveBgId =
                    bulkConfig.bgRotationMode === 'cycle'
                      ? SAMPLE_CLIPS[idx % SAMPLE_CLIPS.length].id
                      : row.backgroundMediaId || SAMPLE_CLIPS[0].id;

                  const clipObj = SAMPLE_CLIPS.find((c) => c.id === effectiveBgId);

                  return (
                    <tr
                      key={row.id}
                      className={`hover:bg-slate-900/40 transition-colors ${
                        isCurrentPreview ? 'bg-cyan-500/10' : ''
                      }`}
                    >
                      {/* Row Index */}
                      <td className="py-3 px-3 text-center font-mono text-slate-500 font-semibold">
                        {idx + 1}
                      </td>

                      {/* Dynamic Columns */}
                      {bulkConfig.columns.map((col) => (
                        <td key={col.id} className="py-2 px-3">
                          <input
                            type="text"
                            value={row.data[col.key] || ''}
                            onChange={(e) => handleCellChange(row.id, col.key, e.target.value)}
                            placeholder={`Enter ${col.name}...`}
                            className="w-full bg-slate-900/80 hover:bg-slate-900 focus:bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none transition-colors"
                          />
                        </td>
                      ))}

                      {/* Video Background Selection Per Row */}
                      <td className="py-2 px-3">
                        <select
                          value={row.backgroundMediaId || SAMPLE_CLIPS[idx % SAMPLE_CLIPS.length].id}
                          onChange={(e) => handleRowBgChange(row.id, e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 truncate"
                        >
                          {SAMPLE_CLIPS.map((clip) => (
                            <option key={clip.id} value={clip.id}>
                              {clip.name} ({clip.width}x{clip.height})
                            </option>
                          ))}
                        </select>
                      </td>

                      {/* Live Canvas Preview Button */}
                      <td className="py-2 px-3 text-center">
                        <button
                          onClick={() => {
                            onSelectPreviewRow(idx);
                          }}
                          className={`px-3 py-1 rounded text-xs font-semibold transition-colors flex items-center justify-center gap-1 mx-auto ${
                            isCurrentPreview
                              ? 'bg-cyan-500 text-slate-950 shadow-sm'
                              : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
                          }`}
                          title="Preview this exact video in canvas"
                        >
                          {isCurrentPreview ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Active</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3 h-3" />
                              <span>Preview</span>
                            </>
                          )}
                        </button>
                      </td>

                      {/* Delete Row */}
                      <td className="py-2 px-3 text-center">
                        <button
                          onClick={() => handleDeleteRow(row.id)}
                          className="text-slate-500 hover:text-red-400 p-1 rounded transition-colors"
                          title="Delete row"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Add Row Button */}
          <button
            onClick={handleAddRow}
            className="w-full py-2.5 rounded-xl border border-dashed border-slate-700 hover:border-cyan-500/60 bg-slate-950/40 hover:bg-slate-900/60 text-slate-400 hover:text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Next Video Row (With Auto Background Rotation)</span>
          </button>
        </div>

        {/* Modal Bottom Footer (Summary & Batch Render Button) */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="font-semibold text-white">
              Total Bulk Queue: <span className="font-mono text-cyan-400">{bulkConfig.rows.length}</span> Videos
            </span>
            <span>·</span>
            <span>Aspect Ratio: {project.aspectRatio}</span>
            <span>·</span>
            <span>Resolution: {project.superResolution.upscaleTarget.toUpperCase()}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
            >
              Done & Close
            </button>

            <button
              onClick={handleBatchRenderAll}
              disabled={isBatchExporting || bulkConfig.rows.length === 0}
              className="px-6 py-2 rounded-lg bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:opacity-95 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-500/20 active:scale-95 transition-all"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>
                {isBatchExporting
                  ? `Rendering Video ${currentBatchIndex + 1}/${bulkConfig.rows.length} (${batchProgress}%)...`
                  : `Batch Render All (${bulkConfig.rows.length} Videos)`}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* CSV Raw Text Modal */}
      {csvTextModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Paste CSV Data</h3>
              <button
                onClick={() => setCsvTextModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-400">
              Format: First line headers (e.g. <code>Hook,Quote,Author</code>), followed by data rows.
            </p>
            <textarea
              rows={6}
              value={csvRawText}
              onChange={(e) => setCsvRawText(e.target.value)}
              placeholder="Hook,Quote,Author&#10;STOP SCROLLING ⚡,Your habits define your future.,Mindset&#10;RULE #1 🔥,Action beats anxiety every time.,Wisdom"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setCsvTextModalOpen(false)}
                className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleParseCsv}
                className="px-4 py-1.5 rounded bg-cyan-500 text-slate-950 font-bold text-xs"
              >
                Import to Table
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
