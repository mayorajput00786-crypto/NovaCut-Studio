#!/usr/bin/env python3
"""
NovaCut Studio - Master Packaging Suite
Generates:
1. Windows PE Executable (NovaCut-Studio-Installer.exe)
2. Windows Desktop Package (NovaCut-Studio-Windows-Desktop-Setup.zip)
3. Complete Project Source & Build (NovaCut-Studio-Complete-Project.zip)
Places all files in /public/downloads for immediate direct web downloads.
"""

import os
import sys
import zipfile
import shutil
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DOWNLOADS_DIR = ROOT_DIR / "public" / "downloads"
WINDOWS_DIST_DIR = ROOT_DIR / "dist-win"

DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
WINDOWS_DIST_DIR.mkdir(parents=True, exist_ok=True)

# 1. Compile Native PE32+ Executables with MinGW GCC
import subprocess

exe_installer_path = WINDOWS_DIST_DIR / "NovaCut-Studio-Installer.exe"
exe_setup_path = WINDOWS_DIST_DIR / "NovaCut-Studio-Setup.exe"
c_source = ROOT_DIR / "src-win" / "installer_main.c"

cmd = [
    "x86_64-w64-mingw32-gcc",
    "-O2",
    "-s",
    "-mwindows",
    "-static",
    str(c_source),
    "-o",
    str(exe_installer_path),
]
print(f"Compiling Windows native executable with MinGW GCC...")
subprocess.check_call(cmd)
shutil.copy2(exe_installer_path, exe_setup_path)

# Copy directly to public/downloads for direct file download
shutil.copy2(exe_installer_path, DOWNLOADS_DIR / "NovaCut-Studio-Installer.exe")
shutil.copy2(exe_setup_path, DOWNLOADS_DIR / "NovaCut-Studio-Setup.exe")

# 2. Create Windows Batch & VBS Scripts in WINDOWS_DIST_DIR
bat_installer_content = r"""@echo off
title NovaCut AI Video Studio - Desktop Setup
color 0B
cls
echo ===============================================================================
echo            NOVACUT AI VIDEO STUDIO - WINDOWS DESKTOP INSTALLER
echo                 Version 1.0.0 Pro Suite (CapCut + Canva Hybrid)
echo ===============================================================================
echo.
echo [1/5] Checking System Prerequisites...

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Node.js was not detected in PATH.
    echo [*] Attempting automated installation via Windows Package Manager (winget)...
    winget install OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
    if %errorlevel% neq 0 (
        echo [X] Automated winget install failed.
        echo Please download and install Node.js LTS from: https://nodejs.org
        pause
        exit /b 1
    )
    echo [*] Node.js installed successfully.
) else (
    echo [OK] Node.js detected: 
    node -v
)

echo.
echo [2/5] Preparing Local Project Environment...
if not exist ".env" (
    echo Creating .env configuration with Master Owner accounts...
    (
        echo PORT=3000
        echo OWNER_EMAIL_1=josnking01@gmail.com
        echo OWNER_EMAIL_2=mayorajput00786@gmail.com
        echo OWNER_EMAIL_3=admin@novacut.io
    ) > .env
    echo [OK] .env configured.
)

echo.
echo [3/5] Installing Project Dependencies...
if not exist "node_modules" (
    echo Installing npm packages...
    call npm install --no-audit --prefer-offline
) else (
    echo [OK] Dependencies already installed.
)

echo.
echo [4/5] Creating Windows Desktop & Start Menu Shortcuts...
cscript //nologo Install-Shortcuts.vbs

echo.
echo [5/5] Launching NovaCut Studio Desktop Application...
start "" Launch-NovaCut.vbs

echo ===============================================================================
echo [SUCCESS] NovaCut Studio has been installed and launched!
echo Access Master Admin with: josnking01@gmail.com or mayorajput00786@gmail.com
echo ===============================================================================
timeout /t 5 >nul
exit /b 0
"""

vbs_launcher_content = '''\' NovaCut Studio Silent Background Launcher
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
strCurDir = fso.GetParentFolderName(WScript.ScriptFullName)

' 1. Start Server silently in background (0 = hide window)
WshShell.Run "cmd /c cd /d """ & strCurDir & """ && npm start", 0, False

' 2. Wait 2 seconds for server to bind port 3000
WScript.Sleep 2500

' 3. Launch App Window in Microsoft Edge or Chrome (Standalone App Window Mode, no address bar)
strUrl = "http://localhost:3000"
strEdge = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
strEdge64 = "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe"
strChrome = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"

If fso.FileExists(strEdge64) Then
    WshShell.Run """" & strEdge64 & """ --app=" & strUrl & " --window-size=1440,900", 1, False
ElseIf fso.FileExists(strEdge) Then
    WshShell.Run """" & strEdge & """ --app=" & strUrl & " --window-size=1440,900", 1, False
ElseIf fso.FileExists(strChrome) Then
    WshShell.Run """" & strChrome & """ --app=" & strUrl & " --window-size=1440,900", 1, False
Else
    WshShell.Run strUrl, 1, False
End If
'''

vbs_shortcuts_content = '''\' Create Desktop and Start Menu Shortcuts
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
strCurDir = fso.GetParentFolderName(WScript.ScriptFullName)
strDesktop = WshShell.SpecialFolders("Desktop")

' Desktop Shortcut
Set oLink = WshShell.CreateShortcut(strDesktop & "\\NovaCut Studio.lnk")
oLink.TargetPath = "wscript.exe"
oLink.Arguments = """" & strCurDir & "\\Launch-NovaCut.vbs"""
oLink.WorkingDirectory = strCurDir
oLink.Description = "NovaCut AI Video Studio - Professional Video Suite"
oLink.WindowStyle = 1
oLink.Save

' Start Menu Shortcut
strStartMenu = WshShell.SpecialFolders("StartMenu") & "\\Programs"
If fso.FolderExists(strStartMenu) Then
    Set oLink2 = WshShell.CreateShortcut(strStartMenu & "\\NovaCut Studio.lnk")
    oLink2.TargetPath = "wscript.exe"
    oLink2.Arguments = """" & strCurDir & "\\Launch-NovaCut.vbs"""
    oLink2.WorkingDirectory = strCurDir
    oLink2.Description = "NovaCut AI Video Studio"
    oLink2.WindowStyle = 1
    oLink2.Save
End If
'''

urdu_guide_content = """===============================================================================
               NOVACUT STUDIO - INSTALLATION & SETUP GUIDE (URDU)
===============================================================================

پیارے صارف!
NovaCut Studio ایک مکمل AI ویڈیو ایڈیٹر اور کینوا پلس کیپ کٹ ہائبرڈ سافٹ ویئر ہے۔
اس کو اپنی Windows PC / Laptop میں انسٹال اور چلانے کا طریقہ کار درج ذیل ہے:

-------------------------------------------------------------------------------
طریقہ ۱: انسٹالیشن بذریعہ EXE یا BAT (سب سے آسان):
-------------------------------------------------------------------------------
۱. ڈاؤن لوڈ کی گئی ZIP فائل کو Extract (Unzip) کریں۔
۲. فولڈر میں موجود "NovaCut-Studio-Installer.exe" پر ڈبل کلک کریں۔
   (یا آپ "Install-NovaCut-Studio.bat" پر بھی ڈبل کلک کر سکتے ہیں)
۳. یہ فائل خودکار طریقے سے ضروری سیٹنگز مکمل کرے گی اور آپ کے Desktop پر 
   "NovaCut Studio" کا شارٹ کٹ آئیکون بنا دے گی۔
۴. سافٹ ویئر خودبخود ایک خوبصورت ڈیسک ٹاپ ایپ ونڈو میں اوپن ہو جائے گا۔

-------------------------------------------------------------------------------
طریقہ ۲: ڈیلی استعمال (Daily Launch):
-------------------------------------------------------------------------------
- آپ کے ڈیسک ٹاپ پر موجود "NovaCut Studio" آئیکون پر ڈبل کلک کریں 
  یا فولڈر میں "Launch-NovaCut.vbs" چلائیں۔
- بغیر کسی بلیک ونڈو یا کمانڈ پرامپٹ کے ایپ اسٹارٹ ہو جائے گی۔

-------------------------------------------------------------------------------
ماسٹر اونر لاگ ان (Master Owner Login):
-------------------------------------------------------------------------------
- josnking01@gmail.com
- mayorajput00786@gmail.com

جب بھی آپ ان ای میلز سے لاگ ان کریں گے، آپ کو کسی لائسنس کی (Key) کی ضرورت نہیں ہوگی۔
سسٹم خودکار طریقے سے آپ کو لائف ٹائم اونر پریمیم ایکسس فراہم کرے گا۔

-------------------------------------------------------------------------------
کسٹمرز کے لیے لائسنس کی جنریشن:
-------------------------------------------------------------------------------
ایڈمن پینل (Admin Panel) کھولیں اور جتنی چاہیں Pro / Lifetime یا Monthly کیز جنریٹ 
کر کے اپنے صارفین کو فراہم کریں۔

کسی بھی مدد کے لیے:
Admin Email: mayorajput00786@gmail.com / josnking01@gmail.com
===============================================================================
"""

readme_guide_content = """# NovaCut AI Video Studio - Desktop & Offline Edition

## Features Included
- **Multi-Track Timeline:** Video, BGM, Overlays, Transitions, and Custom Subtitles.
- **Auto Social Aspect Ratios:** 9:16 (Reels/TikTok/Shorts), 16:9 (YouTube), 1:1, 4:5.
- **Canva-Style Bulk Generation:** Generate hundreds of videos from data spreadsheets with automatic background replacement.
- **Anti-Copyright Shield:** Audio micro-pitch shifting and visual watermark protection.
- **30-Day Duplicate Protection:** Hash database prevents duplicate re-uploads.
- **AI Upscaler:** Super-resolution for videos below 780p.
- **Master Owner & Admin Licensing Engine:** Google OAuth zero-key lifetime access for `josnking01@gmail.com` and `mayorajput00786@gmail.com`.

## Quick Start on Windows
1. Unzip this package to any folder.
2. Double-click `NovaCut-Studio-Installer.exe` or `Install-NovaCut-Studio.bat`.
3. The installer creates a desktop shortcut and launches NovaCut Studio in full desktop app mode.
"""

# Write files into WINDOWS_DIST_DIR
(WINDOWS_DIST_DIR / "Install-NovaCut-Studio.bat").write_text(bat_installer_content, encoding="utf-8")
(WINDOWS_DIST_DIR / "Launch-NovaCut.vbs").write_text(vbs_launcher_content, encoding="utf-8")
(WINDOWS_DIST_DIR / "Install-Shortcuts.vbs").write_text(vbs_shortcuts_content, encoding="utf-8")
(WINDOWS_DIST_DIR / "URDU-INSTALL-GUIDE.txt").write_text(urdu_guide_content, encoding="utf-8")
(WINDOWS_DIST_DIR / "README-INSTALL-GUIDE.md").write_text(readme_guide_content, encoding="utf-8")

# Also copy to root for users exploring the repo
(ROOT_DIR / "Install-NovaCut-Studio.bat").write_text(bat_installer_content, encoding="utf-8")
(ROOT_DIR / "Launch-NovaCut.vbs").write_text(vbs_launcher_content, encoding="utf-8")
(ROOT_DIR / "URDU-INSTALL-GUIDE.txt").write_text(urdu_guide_content, encoding="utf-8")

# 3. Create NovaCut-Studio-Windows-Desktop-Setup.zip
win_zip_path = DOWNLOADS_DIR / "NovaCut-Studio-Windows-Desktop-Setup.zip"
print(f"Creating Windows Desktop ZIP at: {win_zip_path}")
with zipfile.ZipFile(win_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add installer executables and scripts
    for file_path in WINDOWS_DIST_DIR.glob("*"):
        if file_path.is_file():
            zipf.write(file_path, arcname=f"NovaCut-Studio-Windows/{file_path.name}")
            
    # Include built dist folder
    dist_dir = ROOT_DIR / "dist"
    if dist_dir.exists():
        for file_path in dist_dir.rglob("*"):
            if file_path.is_file():
                rel_path = file_path.relative_to(dist_dir)
                zipf.write(file_path, arcname=f"NovaCut-Studio-Windows/dist/{rel_path}")

    # Include server and package files
    for key_file in ["server.ts", "package.json", "tsconfig.json", "vite.config.ts", ".env.example"]:
        fp = ROOT_DIR / key_file
        if fp.exists():
            zipf.write(fp, arcname=f"NovaCut-Studio-Windows/{key_file}")
            
    # Include server source files and licensing database
    for dir_to_include in ["src", "data"]:
        dp = ROOT_DIR / dir_to_include
        if dp.exists():
            for file_path in dp.rglob("*"):
                if file_path.is_file():
                    rel_path = file_path.relative_to(ROOT_DIR)
                    zipf.write(file_path, arcname=f"NovaCut-Studio-Windows/{rel_path}")

print(f"[OK] Created {win_zip_path} ({win_zip_path.stat().st_size} bytes)")

# 4. Create NovaCut-Studio-Complete-Project.zip
project_zip_path = DOWNLOADS_DIR / "NovaCut-Studio-Complete-Project.zip"
print(f"Creating Complete Project ZIP at: {project_zip_path}")

EXCLUDE_DIRS = {".git", "node_modules", ".cache", "dist-win"}
EXCLUDE_EXTS = {".log", ".tmp"}

with zipfile.ZipFile(project_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        # Don't descend into excluded dirs
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        
        rel_dir = os.path.relpath(root, ROOT_DIR)
        if rel_dir == "public/downloads":
            continue
            
        for f in files:
            ext = os.path.splitext(f)[1]
            if ext in EXCLUDE_EXTS:
                continue
            full_path = os.path.join(root, f)
            arc_path = os.path.join("NovaCut-Studio-Source", os.path.relpath(full_path, ROOT_DIR))
            zipf.write(full_path, arcname=arc_path)

print(f"[OK] Created {project_zip_path} ({project_zip_path.stat().st_size} bytes)")

print("\n--- MASTER PACKAGING COMPLETE ---")
print(f"1. EXE Installer:  {DOWNLOADS_DIR / 'NovaCut-Studio-Installer.exe'}")
print(f"2. Windows ZIP:    {win_zip_path}")
print(f"3. Full Project:   {project_zip_path}")
