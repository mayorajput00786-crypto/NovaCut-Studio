#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    char exePath[MAX_PATH];
    GetModuleFileNameA(NULL, exePath, MAX_PATH);
    
    char* lastSlash = strrchr(exePath, '\\');
    if (lastSlash) {
        *lastSlash = '\0';
    }
    SetCurrentDirectoryA(exePath);

    // 1. Check if Install-NovaCut-Studio.bat exists in the same folder
    char batPath[MAX_PATH];
    snprintf(batPath, MAX_PATH, "%s\\Install-NovaCut-Studio.bat", exePath);

    DWORD attr = GetFileAttributesA(batPath);
    if (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY)) {
        // Direct launch of installer script
        ShellExecuteA(NULL, "open", batPath, NULL, exePath, SW_SHOWNORMAL);
        return 0;
    }

    // 2. Check if Launch-NovaCut.vbs exists in current folder
    char vbsPath[MAX_PATH];
    snprintf(vbsPath, MAX_PATH, "%s\\Launch-NovaCut.vbs", exePath);
    attr = GetFileAttributesA(vbsPath);
    if (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY)) {
        ShellExecuteA(NULL, "open", "wscript.exe", vbsPath, exePath, SW_HIDE);
        return 0;
    }

    // 3. Check if NovaCut-Studio-Windows-Desktop-Setup.zip or NovaCut-Studio-Complete-Project.zip exists in Downloads
    char zip1[MAX_PATH];
    char zip2[MAX_PATH];
    snprintf(zip1, MAX_PATH, "%s\\NovaCut-Studio-Windows-Desktop-Setup.zip", exePath);
    snprintf(zip2, MAX_PATH, "%s\\NovaCut-Studio-Complete-Project.zip", exePath);

    const char* targetZip = NULL;
    if (GetFileAttributesA(zip1) != INVALID_FILE_ATTRIBUTES) {
        targetZip = zip1;
    } else if (GetFileAttributesA(zip2) != INVALID_FILE_ATTRIBUTES) {
        targetZip = zip2;
    }

    if (targetZip != NULL) {
        // Auto-extract using native Windows PowerShell and launch
        char psCmd[MAX_PATH * 3];
        snprintf(psCmd, sizeof(psCmd),
            "-WindowStyle Normal -Command \"Write-Host 'Extracting NovaCut Studio Setup...' -ForegroundColor Cyan; "
            "Expand-Archive -Path '%s' -DestinationPath '%s\\NovaCut-Studio-Installed' -Force; "
            "cd '%s\\NovaCut-Studio-Installed'; "
            "if (Test-Path 'Install-NovaCut-Studio.bat') { start 'Install-NovaCut-Studio.bat' } "
            "elseif (Test-Path 'NovaCut-Studio-Windows\\Install-NovaCut-Studio.bat') { cd 'NovaCut-Studio-Windows'; start 'Install-NovaCut-Studio.bat' }\"",
            targetZip, exePath, exePath);

        ShellExecuteA(NULL, "open", "powershell.exe", psCmd, exePath, SW_SHOWNORMAL);
        return 0;
    }

    // 4. Default message if user downloaded only the .exe without unzipping
    int btn = MessageBoxA(NULL,
        "NovaCut AI Video Studio - Desktop Installer\n\n"
        "To complete setup:\n"
        "1. Please extract (Unzip) 'NovaCut-Studio-Windows-Desktop-Setup.zip'\n"
        "2. Run 'NovaCut-Studio-Installer.exe' or 'Install-NovaCut-Studio.bat' inside the unzipped folder.\n\n"
        "Would you like to open the online Studio in your browser right now?",
        "NovaCut Studio Desktop Setup",
        MB_YESNO | MB_ICONINFORMATION);

    if (btn == IDYES) {
        ShellExecuteA(NULL, "open", "https://ais-pre-p7twebxergo2ygfntubhgq-991742061158.asia-east1.run.app", NULL, NULL, SW_SHOWNORMAL);
    }

    return 0;
}
