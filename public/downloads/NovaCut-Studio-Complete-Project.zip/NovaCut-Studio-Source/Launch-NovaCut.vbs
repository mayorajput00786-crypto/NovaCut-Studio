' NovaCut Studio Silent Background Launcher
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
strCurDir = fso.GetParentFolderName(WScript.ScriptFullName)

' 1. Start Server silently in background (0 = hide window)
WshShell.Run "cmd /c cd /d """ & strCurDir & """ && npm start", 0, False

' 2. Wait 2 seconds for server to bind port 3000
WScript.Sleep 2500

' 3. Launch App Window in Microsoft Edge or Chrome (Standalone App Window Mode, no address bar)
strUrl = "http://localhost:3000"
strEdge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
strEdge64 = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
strChrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"

If fso.FileExists(strEdge64) Then
    WshShell.Run """" & strEdge64 & """ --app=" & strUrl & " --window-size=1440,900", 1, False
ElseIf fso.FileExists(strEdge) Then
    WshShell.Run """" & strEdge & """ --app=" & strUrl & " --window-size=1440,900", 1, False
ElseIf fso.FileExists(strChrome) Then
    WshShell.Run """" & strChrome & """ --app=" & strUrl & " --window-size=1440,900", 1, False
Else
    WshShell.Run strUrl, 1, False
End If
